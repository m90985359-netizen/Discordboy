# Discord Bot — دليل التشغيل والهوست

## كيف تشغّله على Replit
البوت يشتغل تلقائياً هنا بدون أي إعداد إضافي.

---

## كيف تشغّله على هوست خارجي (VPS / Railway / الخ)

### 1. المتطلبات
- Node.js v18 أو أحدث
- `npm` أو `pnpm`

### 2. خطوات التثبيت

```bash
# انسخ المجلد أو ارفع الملفات على السيرفر
cd discord-bot

# ثبّت المكتبات
npm install

# شغّل البوت
node src/index.js
```

### 3. إعداد التوكن

**الطريقة الأولى — ملف `.env`** (الأسهل):
```
أنشئ ملف اسمه `.env` في نفس مجلد `package.json` وضع فيه:
```
```env
DISCORD_TOKEN=ضع_توكن_البوت_هنا
GUILD_ID=ضع_ID_السيرفر_هنا
```
ثم ثبّت مكتبة dotenv:
```bash
npm install dotenv
```
وأضف في أول سطر في `src/index.js`:
```js
require('dotenv').config();
```

**الطريقة الثانية — متغيرات البيئة مباشرة**:
```bash
# Linux / Mac
DISCORD_TOKEN="توكن_البوت" node src/index.js

# Windows CMD
set DISCORD_TOKEN=توكن_البوت && node src/index.js
```

### 4. كيف تحصل على توكن البوت
1. روح: https://discord.com/developers/applications
2. اضغط **New Application** وسمّه
3. من القائمة الجانبية اختر **Bot**
4. اضغط **Reset Token** وانسخ التوكن
5. فعّل هذه الصلاحيات تحت **Privileged Gateway Intents**:
   - ✅ Server Members Intent
   - ✅ Message Content Intent

### 5. كيف تدخل البوت لسيرفرك
استخدم هذا الرابط (غيّر `CLIENT_ID` بـ ID تطبيقك):
```
https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands
```

### 6. GUILD_ID (اختياري لكن مُنصح به)
لو أضفت `GUILD_ID` أوامر الـ `/` تظهر فوراً في سيرفرك.
بدونه تحتاج تنتظر حتى ساعة لظهور أوامر السلاش.

للحصول على GUILD_ID: كليك يمين على اسم السيرفر في الديسكورد ← Copy Server ID

---

## الأوامر الكاملة

| الأمر | الوصف | الصلاحية المطلوبة |
|-------|--------|-------------------|
| `$help` / `/help` | قائمة الأوامر | — |
| `$up @شخص [عدد]` | يرقيه عدد من الرولات | Manage Roles |
| `$down @شخص [عدد]` | ينزله عدد من الرولات | Manage Roles |
| `$mute @شخص [سبب]` | يكتم | Manage Roles |
| `$unmute @شخص` | يرفع الكتم | Manage Roles |
| `$kick @شخص [سبب]` | يطرد | Kick Members |
| `$ban @شخص [سبب]` | يحظر | Ban Members |
| `$warn @شخص السبب` | ينذر ويحفظ الإنذار | Manage Messages |
| `$warns @شخص` | يعرض الإنذارات | — |
| `$clear [عدد]` | يمسح رسائل | Manage Messages |
| `$lock` | يقفل الروم | Manage Channels |
| `$unlock` | يفتح الروم | Manage Channels |
| `$say النص` | البوت يرسل رسالة | Manage Messages |
| `$setstatus playing\|streaming\|watching\|listening النص` | يغير حالة البوت | Administrator |
| `$addreply كلمة رد` | يضيف رد تلقائي | Manage Messages |
| `$reply` | يعرض الردود | — |
| `$deletereply كلمة` | يحذف رد | Manage Messages |
| `$addline كلمة رابط` | يضيف خط تلقائي | Manage Messages |
| `$lines` | يعرض الخطوط | — |
| `$deleteline كلمة` | يحذف خط | Manage Messages |

---

## ملاحظات مهمة
- رول البوت يجب أن يكون **فوق** الرولات التي يتحكم فيها
- بيانات الردود والخطوط والإنذارات تُحفظ في `src/data/`
